# campus-placement-prediction
Campus Placement Prediction System
